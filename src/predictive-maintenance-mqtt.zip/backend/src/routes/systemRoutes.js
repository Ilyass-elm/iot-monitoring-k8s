// src/routes/systemRoutes.js
const express = require('express');
const router = express.Router();
const connectorManager = require('../connectors/connectorManager');
const websocketService = require('../services/websocketService');

// GET /api/system/status
router.get('/status', (req, res) => {
  res.json({
    uptime: process.uptime(),
    connectors: connectorManager.getStatuses(),
    wsClients: websocketService.getClientCount(),
    memory: process.memoryUsage(),
    timestamp: Date.now(),
  });
});

module.exports = router;
