// src/routes/dataRoutes.js
const express = require('express');
const router = express.Router();
const dataStore = require('../services/dataStore');

// GET /api/data/metrics - list all known metric keys
router.get('/metrics', (req, res) => {
  const keys = dataStore.getAllMetricKeys();
  res.json({ metrics: keys, count: keys.length });
});

// GET /api/data/latest - snapshot of all latest values
router.get('/latest', (req, res) => {
  res.json(dataStore.getAllLatest());
});

// GET /api/data/series/:metricKey - time-series for a metric
router.get('/series/:metricKey(*)', (req, res) => {
  const { metricKey } = req.params;
  const limit = parseInt(req.query.limit) || 200;
  const series = dataStore.getSeries(metricKey, limit);
  const stats = dataStore.getStats(metricKey);
  res.json({ metricKey, series, stats, count: series.length });
});

// GET /api/data/sources - connected data sources
router.get('/sources', (req, res) => {
  res.json(dataStore.getSources());
});

// GET /api/data/machines - zuletzt bekannter Status aller Maschinen
router.get('/machines', (req, res) => {
  res.json(dataStore.getMachines());
});

module.exports = router;
