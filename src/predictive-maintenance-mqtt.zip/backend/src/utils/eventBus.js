// src/utils/eventBus.js
// Central event bus: decouples connectors (MQTT, OPC UA, Simulation)
// from the rest of the application (WebSocket broadcaster, AI service, etc.)

const EventEmitter = require('events');

class EventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(50);
  }
}

// Singleton
const eventBus = new EventBus();
module.exports = eventBus;
