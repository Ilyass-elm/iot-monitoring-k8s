// src/connectors/wsSourceConnector.js
// Einziger Datenanschluss der Anwendung: ein WebSocket-CLIENT, der sich zur
// dashboard-api verbindet (siehe backend/main.py der Datenquelle).
//
// Nachrichtenformat der Quelle (unterschieden über das Feld "type"):
//   { "type": "ems",       "ems": { machine_id: status, ... } }   ← initiale Liste
//   { "type": "status",    "machine_id": ..., "status": ... }    ← Status-Update
//   { "type": "telemetry", "machine_id": ..., "axis": ..., "value": ... }  ← Messwert
//
// WICHTIG: Der Server schickt Telemetrie NUR an Clients, die die jeweilige
// Maschine per { action: "select_machine", machine_id } ausgewählt haben.
// Ohne diese Auswahl bleibt die Verbindung offen, aber es kommen nie Daten an.

const WebSocket = require('ws');
const eventBus = require('../utils/eventBus');
const logger = require('../utils/logger');

class WsSourceConnector {
  constructor(config = {}) {
    this.id = 'ws-source';
    this.config = config;
    this.ws = null;
    this.connected = false;
    this.reconnectTimer = null;
    this.reconnectDelayMs = config.reconnectDelayMs || 3000;
    this._knownMachines = new Set();
  }

  connect() {
    const { url } = this.config;
    logger.info(`[WsSource] Verbinde zu ${url}`);

    this.ws = new WebSocket(url);

    this.ws.on('open', () => {
      this.connected = true;
      this._knownMachines.clear(); // nach Reconnect erneut alle Maschinen abonnieren
      logger.info(`[WsSource] Verbunden mit ${url}`);
      eventBus.emit('source:connected', { id: this.id, type: 'WebSocket', url });
    });

    this.ws.on('message', (raw) => this._handleMessage(raw));

    this.ws.on('error', (err) => {
      logger.error('[WsSource] Fehler:', err.message);
      eventBus.emit('source:error', { id: this.id, error: err.message });
    });

    this.ws.on('close', () => {
      this.connected = false;
      logger.warn('[WsSource] Verbindung getrennt, versuche erneut in ' + this.reconnectDelayMs + 'ms');
      eventBus.emit('source:disconnected', { id: this.id });
      this._scheduleReconnect();
    });
  }

  _scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, this.reconnectDelayMs);
  }

  _handleMessage(raw) {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch (err) {
      logger.warn('[WsSource] Konnte Nachricht nicht parsen:', err.message);
      return;
    }

    switch (msg.type) {
      case 'ems':
        // { type: "ems", ems: { machine_id: status, ... } }
        this._handleMachineList(msg.ems || {});
        break;

      case 'status':
        // { type: "status", machine_id, status }
        this._handleStatus(msg.machine_id, msg.status);
        this._ensureSelected(msg.machine_id);
        break;

      case 'telemetry':
        // { type: "telemetry", machine_id, axis, value }
        this._handleTelemetry(msg.machine_id, msg.axis, msg.value);
        break;

      default:
        logger.warn('[WsSource] Unbekannter Nachrichtentyp, ignoriert:', JSON.stringify(msg).slice(0, 200));
    }
  }

  _handleMachineList(emsMap) {
    for (const [machineId, status] of Object.entries(emsMap)) {
      this._handleStatus(machineId, status);
      this._ensureSelected(machineId);
    }
  }

  /** Maschine genau einmal abonnieren, sobald sie uns zum ersten Mal begegnet */
  _ensureSelected(machineId) {
    if (!machineId || this._knownMachines.has(machineId)) return;
    this._knownMachines.add(machineId);
    this._selectMachine(machineId);
  }

  _selectMachine(machineId) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ action: 'select_machine', machine_id: machineId }));
    logger.info(`[WsSource] Maschine abonniert: ${machineId}`);
  }

  _handleStatus(machineId, status) {
    if (!machineId) return;
    eventBus.emit('machine:status', { machineId, status, timestamp: Date.now() });
  }

  _handleTelemetry(machineId, axis, value) {
    if (!machineId || !axis) return;
    const numeric = typeof value === 'number' ? value : parseFloat(value);
    if (Number.isNaN(numeric)) return; // nur tatsächlich eingetroffene, numerische Messwerte anzeigen

    eventBus.emit('data:point', {
      metricKey: `${machineId}.${axis}`,
      value: numeric,
      source: this.id,
      tags: { machine: machineId, metric: axis },
    });
  }

  disconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.ws) this.ws.close();
  }

  getStatus() {
    return { id: this.id, type: 'WebSocket', connected: this.connected, url: this.config.url };
  }
}

module.exports = WsSourceConnector;

