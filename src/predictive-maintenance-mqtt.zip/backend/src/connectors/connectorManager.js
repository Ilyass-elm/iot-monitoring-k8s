// src/connectors/connectorManager.js
// Orchestrates connector lifecycle. Register connectors here to extend.

const eventBus = require('../utils/eventBus');
const dataStore = require('../services/dataStore');
const logger = require('../utils/logger');

class ConnectorManager {
  constructor() {
    this._connectors = new Map();
    this._setupEventHandlers();
  }

  _setupEventHandlers() {
    // Ingest all data points into the store
    eventBus.on('data:point', (pointOrArray) => {
      const points = Array.isArray(pointOrArray) ? pointOrArray : [pointOrArray];
      for (const p of points) {
        if (typeof p.value === 'number' && !isNaN(p.value)) {
          dataStore.push(p.metricKey, p.value, p.source, p.tags || {});
        }
      }
    });

    eventBus.on('source:connected', ({ id, type, url }) => {
      dataStore.registerSource(id, { type, url });
      logger.info(`[ConnectorManager] Source connected: ${id} (${type})`);
    });

    eventBus.on('source:disconnected', ({ id }) => {
      dataStore.unregisterSource(id);
    });

    // Maschinen-Status (aktive Maschinen im Dashboard)
    eventBus.on('machine:status', ({ machineId, status }) => {
      dataStore.updateMachine(machineId, status);
    });
  }

  register(connector) {
    this._connectors.set(connector.id, connector);
    logger.info(`[ConnectorManager] Registered connector: ${connector.id}`);
  }

  async startAll() {
    for (const [id, connector] of this._connectors) {
      try {
        if (typeof connector.connect === 'function') await connector.connect();
        else if (typeof connector.start === 'function') connector.start();
      } catch (err) {
        logger.error(`[ConnectorManager] Failed to start ${id}:`, err.message);
      }
    }
  }

  async stopAll() {
    for (const [id, connector] of this._connectors) {
      try {
        if (typeof connector.disconnect === 'function') await connector.disconnect();
        else if (typeof connector.stop === 'function') connector.stop();
      } catch (err) {
        logger.warn(`[ConnectorManager] Error stopping ${id}:`, err.message);
      }
    }
  }

  getStatuses() {
    const statuses = {};
    for (const [id, connector] of this._connectors) {
      statuses[id] = connector.getStatus();
    }
    return statuses;
  }
}

module.exports = new ConnectorManager();
