// src/connectors/mqttSourceConnector.js
// MQTT-Connector: verbindet sich als Client zu einem Broker, abonniert die in
// src/config/mqttConfig.js definierten Topics und speist eingehende Werte in
// den eventBus ein (gleiches Zielformat wie wsSourceConnector.js: 'data:point',
// 'machine:status', 'source:connected'/'source:disconnected').
//
// Topics, Platzhalter und Nachrichtentypen werden ausschließlich über
// mqttConfig.js gepflegt — hier steht nur die generische Verarbeitungslogik.

const mqtt = require('mqtt');
const eventBus = require('../utils/eventBus');
const logger = require('../utils/logger');

/** Wandelt ein Topic-Pattern mit {platzhaltern}/+/# in einen RegExp inkl. Namen der Platzhalter um. */
function compilePattern(pattern) {
  // paramNames wird NUR für tatsächliche Capture-Groups befüllt (in ihrer
  // Reihenfolge), damit der Index exakt zu regex.exec()[i] passt.
  const paramNames = [];
  const segments = pattern.split('/').map((seg) => {
    if (seg === '#') return '.*'; // Mehrfach-Level-Wildcard, keine Extraktion
    if (seg === '+') {
      paramNames.push(null); // ein Level, aber kein benannter Platzhalter
      return '([^/]+)';
    }
    const namedMatch = seg.match(/^\{(\w+)\}$/);
    if (namedMatch) {
      paramNames.push(namedMatch[1]);
      return '([^/]+)';
    }
    return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // literales Segment, keine Gruppe
  });
  return { regex: new RegExp(`^${segments.join('/')}$`), paramNames };
}

/** Wandelt ein Topic-Pattern in ein für MQTT-Subscriptions gültiges Topic um ({name} -> +). */
function toSubscribeTopic(pattern) {
  return pattern
    .split('/')
    .map((seg) => (/^\{\w+\}$/.test(seg) ? '+' : seg))
    .join('/');
}

class MqttSourceConnector {
  constructor(config = {}) {
    this.id = 'mqtt-source';
    this.config = config;
    this.client = null;
    this.connected = false;

    // Topic-Patterns aus der Konfiguration einmalig kompilieren
    this._compiledTopics = (config.topics || []).map((entry) => ({
      ...entry,
      ...compilePattern(entry.topic),
      subscribeTopic: toSubscribeTopic(entry.topic),
    }));
  }

  connect() {
    const { brokerUrl, clientId, username, password, reconnectPeriodMs, connectTimeoutMs } = this.config;
    logger.info(`[MqttSource] Verbinde zu ${brokerUrl}`);

    this.client = mqtt.connect(brokerUrl, {
      clientId,
      username,
      password,
      reconnectPeriod: reconnectPeriodMs,
      connectTimeout: connectTimeoutMs,
    });

    this.client.on('connect', () => {
      this.connected = true;
      logger.info(`[MqttSource] Verbunden mit ${brokerUrl}`);
      eventBus.emit('source:connected', { id: this.id, type: 'MQTT', url: brokerUrl });

      for (const t of this._compiledTopics) {
        const qos = t.qos ?? this.config.defaultQos ?? 0;
        this.client.subscribe(t.subscribeTopic, { qos }, (err) => {
          if (err) logger.error(`[MqttSource] Konnte Topic nicht abonnieren (${t.subscribeTopic}):`, err.message);
          else logger.info(`[MqttSource] Topic abonniert: ${t.subscribeTopic} (${t.type})`);
        });
      }
    });

    this.client.on('message', (topic, payload) => this._handleMessage(topic, payload));

    this.client.on('error', (err) => {
      logger.error('[MqttSource] Fehler:', err.message);
      eventBus.emit('source:error', { id: this.id, error: err.message });
    });

    this.client.on('close', () => {
      if (this.connected) {
        this.connected = false;
        logger.warn('[MqttSource] Verbindung getrennt');
        eventBus.emit('source:disconnected', { id: this.id });
      }
    });
  }

  _handleMessage(topic, payloadBuf) {
    const match = this._compiledTopics.find((t) => t.regex.test(topic));
    if (!match) {
      logger.warn(`[MqttSource] Kein Mapping für Topic gefunden, ignoriert: ${topic}`);
      return;
    }

    const params = this._extractParams(topic, match);
    const raw = payloadBuf.toString();
    const json = this._tryParseJson(raw);

    switch (match.type) {
      case 'telemetry':
        this._handleTelemetry(
          params.machineId || json?.machine_id,
          params.axis || json?.axis,
          json && typeof json.value !== 'undefined' ? json.value : raw
        );
        break;

      case 'status':
        this._handleStatus(params.machineId || json?.machine_id, json?.status ?? raw);
        break;

      case 'ems':
        this._handleMachineList(json || {});
        break;

      default:
        logger.warn(`[MqttSource] Unbekannter type in mqttConfig für Topic ${match.topic}: ${match.type}`);
    }
  }

  _extractParams(topic, compiled) {
    const values = topic.match(compiled.regex);
    const params = {};
    if (!values) return params;
    compiled.paramNames.forEach((name, idx) => {
      if (name) params[name] = values[idx + 1];
    });
    return params;
  }

  _tryParseJson(raw) {
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  _handleMachineList(emsMap) {
    for (const [machineId, status] of Object.entries(emsMap)) {
      this._handleStatus(machineId, status);
    }
  }

  _handleStatus(machineId, status) {
    if (!machineId) return;
    eventBus.emit('machine:status', { machineId, status, timestamp: Date.now() });
  }

  _handleTelemetry(machineId, axis, value) {
    if (!machineId || !axis) return;
    const numeric = typeof value === 'number' ? value : parseFloat(value);
    if (Number.isNaN(numeric)) return;

    eventBus.emit('data:point', {
      metricKey: `${machineId}.${axis}`,
      value: numeric,
      source: this.id,
      tags: { machine: machineId, metric: axis },
    });
  }

  disconnect() {
    if (this.client) this.client.end(true);
  }

  getStatus() {
    return { id: this.id, type: 'MQTT', connected: this.connected, url: this.config.brokerUrl };
  }
}

module.exports = MqttSourceConnector;
