// src/services/dataStore.js
// In-memory ring buffer for sensor time-series data.
// Keeps the last MAX_POINTS readings per metric for charting.

const MAX_POINTS = 500;

class DataStore {
  constructor() {
    // { metricKey: [{ timestamp, value, source, tags }] }
    this._series = {};
    // { metricKey: { min, max, avg, last, count } }
    this._stats = {};
    // connected data sources
    this._sources = {};
    // { machine_id: { machine_id, status, updatedAt } }
    this._machines = {};
  }

  /** Ingest a single data point */
  push(metricKey, value, source = 'unknown', tags = {}) {
    const point = {
      timestamp: Date.now(),
      value: typeof value === 'number' ? value : parseFloat(value),
      source,
      tags,
    };

    if (!this._series[metricKey]) this._series[metricKey] = [];
    const series = this._series[metricKey];
    series.push(point);
    if (series.length > MAX_POINTS) series.shift();

    this._updateStats(metricKey, point.value);
    return point;
  }

  _updateStats(key, value) {
    if (!this._stats[key]) {
      this._stats[key] = { min: value, max: value, sum: 0, count: 0, last: value };
    }
    const s = this._stats[key];
    s.min = Math.min(s.min, value);
    s.max = Math.max(s.max, value);
    s.sum += value;
    s.count++;
    s.last = value;
    s.avg = s.sum / s.count;
  }

  getSeries(metricKey, limit = MAX_POINTS) {
    const series = this._series[metricKey] || [];
    return series.slice(-limit);
  }

  getAllMetricKeys() {
    return Object.keys(this._series);
  }

  getStats(metricKey) {
    return this._stats[metricKey] || null;
  }

  getAllLatest() {
    const result = {};
    for (const key of Object.keys(this._series)) {
      const series = this._series[key];
      if (series.length > 0) {
        result[key] = { ...series[series.length - 1], stats: this._stats[key] };
      }
    }
    return result;
  }

  registerSource(id, info) {
    this._sources[id] = { ...info, connectedAt: Date.now() };
  }

  unregisterSource(id) {
    delete this._sources[id];
  }

  getSources() {
    return { ...this._sources };
  }

  /** Status-Update einer Maschine speichern (nur eingetroffene Stände) */
  updateMachine(machineId, status) {
    this._machines[machineId] = { machine_id: machineId, status, updatedAt: Date.now() };
  }

  getMachines() {
    return Object.values(this._machines);
  }
}

module.exports = new DataStore();
