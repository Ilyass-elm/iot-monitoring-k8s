// src/services/websocketService.js
// Broadcasts real-time events to all connected WebSocket clients.
// Subscribes to eventBus and fans out to clients.

const { WebSocketServer } = require('ws');
const eventBus = require('../utils/eventBus');
const logger = require('../utils/logger');

class WebSocketService {
  constructor() {
    this.wss = null;
    this.clients = new Set();
  }

  init(server) {
    this.wss = new WebSocketServer({ server });

    this.wss.on('connection', (ws, req) => {
      this.clients.add(ws);
      logger.info(`[WS] Client connected (total: ${this.clients.size})`);

      ws.on('close', () => {
        this.clients.delete(ws);
        logger.info(`[WS] Client disconnected (total: ${this.clients.size})`);
      });

      ws.on('error', (err) => {
        logger.warn('[WS] Client error:', err.message);
        this.clients.delete(ws);
      });

      // Send welcome / sync message
      this._send(ws, { type: 'connected', payload: { message: 'Predictive Maintenance Stream' } });
    });

    this._setupEventForwarding();
    logger.info('[WS] WebSocket server attached to HTTP server');
  }

  _setupEventForwarding() {
    // Forward data points
    eventBus.on('data:point', (point) => {
      const points = Array.isArray(point) ? point : [point];
      this.broadcast({ type: 'data:point', payload: points });
    });

    // Forward machine status changes (für "Aktive Maschinen" im Dashboard)
    eventBus.on('machine:status', (info) => {
      this.broadcast({ type: 'machine:status', payload: info });
    });

    // Source connection changes
    eventBus.on('source:connected', (info) => {
      this.broadcast({ type: 'source:connected', payload: info });
    });

    eventBus.on('source:disconnected', (info) => {
      this.broadcast({ type: 'source:disconnected', payload: info });
    });

    eventBus.on('source:error', (info) => {
      this.broadcast({ type: 'source:error', payload: info });
    });
  }

  broadcast(message) {
    if (this.clients.size === 0) return;
    const json = JSON.stringify(message);
    for (const ws of this.clients) {
      if (ws.readyState === ws.OPEN) {
        try {
          ws.send(json);
        } catch (err) {
          logger.warn('[WS] Send error:', err.message);
          this.clients.delete(ws);
        }
      }
    }
  }

  _send(ws, message) {
    try {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(message));
    } catch (err) {
      logger.warn('[WS] Send error:', err.message);
    }
  }

  getClientCount() {
    return this.clients.size;
  }
}

module.exports = new WebSocketService();
