// src/config/mqttConfig.js
//
// Zentrale Konfiguration der MQTT-Anbindung.
// Diese Datei ist bewusst von der Connector-Logik (mqttSourceConnector.js)
// getrennt: Verbindungsdaten und Topics werden HIER angepasst, ohne dass
// im Connector-Code etwas geändert werden muss.
//
// ── Verbindung ───────────────────────────────────────────────────────────
// Alle Werte sind per .env überschreibbar (siehe backend/.env).

module.exports = {
  enabled: process.env.MQTT_ENABLED !== 'false', // per MQTT_ENABLED=false abschaltbar

  brokerUrl: process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883',
  clientId: process.env.MQTT_CLIENT_ID || `predictmaint-${Math.random().toString(16).slice(2, 8)}`,
  username: process.env.MQTT_USERNAME || undefined,
  password: process.env.MQTT_PASSWORD || undefined,

  reconnectPeriodMs: parseInt(process.env.MQTT_RECONNECT_MS || '3000', 10),
  connectTimeoutMs: parseInt(process.env.MQTT_CONNECT_TIMEOUT_MS || '10000', 10),
  defaultQos: parseInt(process.env.MQTT_QOS || '0', 10),

  // ── Topic-Zuordnung ────────────────────────────────────────────────────
  // Neue Topics werden ausschließlich hier eingetragen. Der Connector liest
  // diese Liste beim Start aus, abonniert die Topics und ordnet eingehende
  // Nachrichten anhand des "type"-Felds automatisch zu.
  //
  // Platzhalter im Topic-Pattern:
  //   {machineId}   -> wird als Maschinen-ID extrahiert
  //   {axis}        -> wird als Messgrößen-/Achsenname extrahiert
  //   +             -> ein Level, wird ignoriert (kein Platzhalter)
  //   #             -> Mehrfach-Level-Wildcard (nur am Ende erlaubt)
  //
  // type:
  //   'telemetry' -> Payload ist eine Zahl (z.B. "23.5") ODER JSON { value }.
  //                  machineId/axis kommen bevorzugt aus dem Topic, sonst
  //                  aus dem JSON-Payload (machine_id / axis).
  //   'status'    -> Payload ist ein String (z.B. "running") ODER JSON { status }.
  //   'ems'       -> Payload ist JSON { machine_id: status, ... } (Initialliste
  //                  aller Maschinen, analog zum bestehenden WS-Format).
  //
  // Beispiel zum Hinzufügen eines neuen Sensors:
  //   { topic: 'werk1/{machineId}/vibration', type: 'telemetry' }
  topics: [
    { topic: 'machines/{machineId}/telemetry/{axis}', type: 'telemetry' },
    { topic: 'machines/{machineId}/status', type: 'status' },
    { topic: 'machines/ems', type: 'ems' },
  ],
};
