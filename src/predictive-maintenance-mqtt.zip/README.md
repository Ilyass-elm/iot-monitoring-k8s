# PredictMaint — Predictive Maintenance Platform

Industrial IoT Dashboard mit einem einzigen WebSocket-Datenanschluss.
Zeigt eingetroffene Maschinen-Status und Messdaten live an. Der KI-Reiter
ist als Platzhalter vorbereitet, bis ein echtes Modell angebunden wird.

## 🏗 Architektur

```
┌─────────────────────────────────────────┐
│      EXTERNE QUELLE (WebSocket-Server)   │
│   sendet: Maschinenliste, Status-        │
│   Updates, Messdaten (machine_id + Felder)│
└───────────────────┬──────────────────────┘
                     │ WebSocket-Client
                     ▼
┌─────────────────────────────────────────┐
│         WsSourceConnector                │  ← einziger Datenanschluss
│  (verbindet, wählt Maschinen aus,        │
│   unterscheidet Status- vs. Datennachr.) │
└───────────────────┬──────────────────────┘
                     │ machine:status / data:point
                     ▼
┌────────────────────────────────────┐
│           EventBus (pub/sub)        │
└──────┬───────────────────────────────┘
       ▼
┌────────────┐
│ DataStore  │   ← Maschinen-Status + Ring-Buffer je Metrik
└─────┬──────┘
      ▼
┌──────────────────┐
│ WebSocketService  │  ← Broadcast an alle Frontend-Clients
└────────┬──────────┘
         │ ws://
         ▼
┌─────────────────────────────────────────┐
│              REACT FRONTEND              │
│   Dashboard │ Live Feed │ KI-Analyse     │
└─────────────────────────────────────────┘
```

## 📁 Projektstruktur

```
predictive-maintenance/
├── backend/
│   ├── src/
│   │   ├── connectors/
│   │   │   ├── connectorManager.js
│   │   │   └── wsSourceConnector.js   # einziger Datenanschluss (WS-Client)
│   │   ├── services/
│   │   │   ├── dataStore.js           # Ring-Buffer + Maschinen-Registry
│   │   │   └── websocketService.js    # Broadcast ans Frontend
│   │   ├── routes/
│   │   │   ├── dataRoutes.js          # /api/data/*
│   │   │   └── systemRoutes.js        # /api/system/status
│   │   ├── utils/
│   │   │   ├── eventBus.js
│   │   │   └── logger.js
│   │   └── server.js
│   └── .env
│
└── frontend/
    └── src/
        ├── views/
        │   ├── DashboardView.jsx      # Aktive Maschinen + Daten-Übersicht
        │   ├── LiveFeedView.jsx       # Roher Live-Datenstrom
        │   └── AiView.jsx             # Platzhalter, noch kein Modell
        ├── components/
        │   ├── ui/index.jsx
        │   ├── Header.jsx
        │   └── MetricCard.jsx
        ├── hooks/
        │   └── useWebSocket.js        # useMachines, useAllMetrics, useMetricSeries
        ├── services/
        │   ├── apiService.js
        │   └── websocketService.js
        └── styles/
            └── main.css
```

## 🚀 Quickstart

```bash
npm run install:all      # Abhängigkeiten
npm run dev:backend      # Backend auf Port 3001
npm run dev:frontend     # Frontend auf Port 5173
```

Öffne: **http://localhost:5173**

## ⚙️ Konfiguration (`backend/.env`)

| Variable | Standard | Beschreibung |
|---|---|---|
| `WS_SOURCE_URL` | — | Volle URL zur externen Quelle, überschreibt Host/Port/Pfad |
| `WS_SOURCE_HOST` | `dashboard-api` | Host der externen Quelle |
| `WS_SOURCE_PORT` | `8000` | Port der externen Quelle |
| `WS_SOURCE_PATH` | `/ws/live` | Pfad der externen Quelle |

Die Defaults entsprechen der Vorlage `webSocket/webSocket_client.py`.

## 📨 Nachrichtenformat der externen Quelle (Annahme)

Der Connector (`backend/src/connectors/wsSourceConnector.js`) geht von
folgendem Format aus — **falls eure echte Quelle abweicht, hier anpassen**:

- **Initiale Nachricht / Maschinenliste**: Array oder `{ machines: [...] }`
  mit Einträgen `{ machine_id, status }`
- **Status-Update**: `{ machine_id, status }`
- **Messdaten**: `{ machine_id, <Feldname>: <Zahl>, ... }` — beliebig viele
  Felder, die Feldnamen (z.B. `Temp`, `Lenkung`) werden dynamisch als
  Metriken übernommen. Erkennung: hat die Nachricht ein `status`-Feld, wird
  sie als Status behandelt, sonst als Messdaten.

Die Anpassung an das echte Format erfolgt zentral in `_handleMessage()`.

## 🤖 KI-Modell später anbinden

`frontend/src/views/AiView.jsx` ist aktuell ein reiner Platzhalter.
Sobald ein Modell steht: eigene Backend-Route (z.B. `backend/src/routes/aiRoutes.js`
neu anlegen) + im Frontend per `api.js` abrufen und in `AiView.jsx` darstellen.

## 📡 REST API

| Endpoint | Beschreibung |
|---|---|
| `GET /api/data/metrics` | Alle bekannten Metrik-Keys |
| `GET /api/data/latest` | Letzter Wert aller Metriken |
| `GET /api/data/series/:key` | Zeitreihe einer Metrik |
| `GET /api/data/sources` | Verbundene Datenquelle |
| `GET /api/data/machines` | Zuletzt bekannter Status aller Maschinen |
| `GET /api/system/status` | System-Status |

## 📨 WebSocket-Events (Backend → Frontend)

| Event | Payload |
|---|---|
| `data:point` | `[{ metricKey, value, timestamp, source, tags }]` |
| `machine:status` | `{ machineId, status, timestamp }` |
| `source:connected` | `{ id, type, url }` |
| `source:disconnected` | `{ id }` |
