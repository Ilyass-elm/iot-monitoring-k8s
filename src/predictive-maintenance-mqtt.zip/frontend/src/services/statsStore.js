// src/services/statsStore.js
// Zählt eingetroffene Datenpunkte global, unabhängig vom aktiven Tab —
// gleiches Prinzip wie liveFeedStore.js.
import { wsService } from './websocketService';

let totalPoints = 0;
const listeners = new Set();

wsService.on('data:point', (points) => {
  const arr = Array.isArray(points) ? points : [points];
  totalPoints += arr.length;
  for (const fn of listeners) fn(totalPoints);
});

export const statsStore = {
  getTotalPoints: () => totalPoints,
  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
};
