// src/services/liveFeedStore.js
// Sammelt eingehende Daten- und Status-Nachrichten GLOBAL, unabhängig davon,
// ob der Live-Feed-Tab gerade sichtbar/gemountet ist. Der Listener hängt
// direkt am wsService (Modul-Singleton) und läuft ab dem Zeitpunkt, an dem
// dieses Modul zum ersten Mal importiert wird (siehe App.jsx) — also ab
// App-Start, nicht erst beim Klick auf den Tab.
import { wsService } from './websocketService';

const MAX_ROWS = 200;
let rows = [];
const listeners = new Set();

function pushRows(newRows) {
  rows = [...newRows, ...rows];
  if (rows.length > MAX_ROWS) rows.length = MAX_ROWS;
  for (const fn of listeners) fn(rows);
}

wsService.on('data:point', (points) => {
  const arr = Array.isArray(points) ? points : [points];
  pushRows(
    arr.map((p) => ({
      id: `${p.metricKey}-${p.timestamp}`,
      timestamp: p.timestamp,
      type: 'daten',
      machine: p.tags?.machine || '—',
      label: p.tags?.metric || p.metricKey,
      value: p.value,
    }))
  );
});

wsService.on('machine:status', ({ machineId, status, timestamp }) => {
  pushRows([
    {
      id: `${machineId}-status-${timestamp}`,
      timestamp,
      type: 'status',
      machine: machineId,
      label: 'status',
      value: status,
    },
  ]);
});

export const liveFeedStore = {
  MAX_ROWS,
  getRows: () => rows,
  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  clear() {
    rows = [];
    for (const fn of listeners) fn(rows);
  },
};
