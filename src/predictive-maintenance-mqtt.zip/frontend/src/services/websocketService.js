// src/services/websocketService.js
// Manages the WebSocket connection to the backend.
// Emits events via a simple EventEmitter pattern.

const WS_URL = `ws://${window.location.host}`;
const RECONNECT_DELAY = 3000;

class WebSocketService {
  constructor() {
    this._ws = null;
    this._listeners = {};
    this._reconnectTimer = null;
    this._connected = false;
  }

  connect() {
    if (this._ws) return;
    this._connect();
  }

  _connect() {
    const url = import.meta.env.PROD
      ? WS_URL
      : 'ws://localhost:3001';

    this._ws = new WebSocket(url);

    this._ws.onopen = () => {
      this._connected = true;
      this._emit('connection', { connected: true });
      if (this._reconnectTimer) {
        clearTimeout(this._reconnectTimer);
        this._reconnectTimer = null;
      }
    };

    this._ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        this._emit(message.type, message.payload);
        this._emit('*', message); // wildcard listener
      } catch (err) {
        console.warn('[WS] Parse error:', err);
      }
    };

    this._ws.onclose = () => {
      this._connected = false;
      this._ws = null;
      this._emit('connection', { connected: false });
      this._reconnectTimer = setTimeout(() => this._connect(), RECONNECT_DELAY);
    };

    this._ws.onerror = (err) => {
      console.warn('[WS] Error:', err);
    };
  }

  on(type, handler) {
    if (!this._listeners[type]) this._listeners[type] = [];
    this._listeners[type].push(handler);
    return () => this.off(type, handler);
  }

  off(type, handler) {
    if (!this._listeners[type]) return;
    this._listeners[type] = this._listeners[type].filter((h) => h !== handler);
  }

  _emit(type, data) {
    const handlers = this._listeners[type] || [];
    for (const h of handlers) {
      try { h(data); } catch (err) { console.warn('[WS] Handler error:', err); }
    }
  }

  isConnected() {
    return this._connected;
  }
}

export const wsService = new WebSocketService();
