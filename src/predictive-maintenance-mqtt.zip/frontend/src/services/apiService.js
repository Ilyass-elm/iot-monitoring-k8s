// src/services/apiService.js
const BASE = import.meta.env.PROD ? '' : 'http://localhost:3001';

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`API ${path} → ${res.status}`);
  return res.json();
}

export const api = {
  getMetrics: () => get('/api/data/metrics'),
  getLatest: () => get('/api/data/latest'),
  getSeries: (metricKey, limit = 200) =>
    get(`/api/data/series/${encodeURIComponent(metricKey)}?limit=${limit}`),
  getSources: () => get('/api/data/sources'),
  getMachines: () => get('/api/data/machines'),
  getSystemStatus: () => get('/api/system/status'),
};
