// src/views/AiView.jsx
// Platzhalter: Es ist noch kein KI-Modell angebunden.
// Sobald ein Modell steht, hier z.B. per REST-Route (z.B. /api/ai/...) die
// Vorhersagen/Anomalien abrufen und darstellen.
import { Card, EmptyState } from '../components/ui/index.jsx';

export function AiView() {
  return (
    <div className="view ai-view">
      <Card title="KI-Analyse" subtitle="Noch kein Modell angebunden">
        <EmptyState
          title="Kein Modell trainiert"
          message="Dieser Bereich ist vorbereitet, sobald ein KI-Modell zur Anomalieerkennung angebunden wird."
        />
      </Card>
    </div>
  );
}
