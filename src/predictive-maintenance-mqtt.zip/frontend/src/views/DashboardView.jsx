// src/views/DashboardView.jsx
import { useState, useEffect, useCallback } from 'react';
import { useAllMetrics, useWsEvent, useMachines } from '../hooks/useWebSocket';
import { MetricCard } from '../components/MetricCard.jsx';
import { Card, Badge, EmptyState, StatusDot } from '../components/ui/index.jsx';
import { api } from '../services/apiService';
import { statsStore } from '../services/statsStore';

// Status-Texte, die als "aktiv" gelten (Groß-/Kleinschreibung egal).
// Bei Bedarf an eure echten Status-Werte anpassen.
const ACTIVE_STATUSES = ['online', 'active', 'running', 'ok'];

function isActive(status) {
  return ACTIVE_STATUSES.includes(String(status).toLowerCase());
}

export function DashboardView() {
  const metrics = useAllMetrics();
  const machines = useMachines();
  const [sources, setSources] = useState({});
  const [pointCount, setPointCount] = useState(statsStore.getTotalPoints());

  useEffect(() => {
    api.getSources().then(setSources).catch(() => {});
  }, []);

  useEffect(() => statsStore.subscribe(setPointCount), []);

  useWsEvent('source:connected', useCallback((info) => {
    setSources((prev) => ({ ...prev, [info.id]: info }));
  }, []));

  const metricKeys = Object.keys(metrics);
  const sourceList = Object.values(sources);
  const machineList = Object.values(machines);
  const activeMachineCount = machineList.filter((m) => isActive(m.status)).length;

  return (
    <div className="view dashboard-view">
      {/* KPI Row */}
      <div className="kpi-row">
        <div className="kpi-tile">
          <div className="kpi-value">{machineList.length}</div>
          <div className="kpi-label">Bekannte Maschinen</div>
        </div>
        <div className="kpi-tile">
          <div className="kpi-value">{activeMachineCount}</div>
          <div className="kpi-label">Aktiv</div>
        </div>
        <div className="kpi-tile">
          <div className="kpi-value">{metricKeys.length}</div>
          <div className="kpi-label">Aktive Metriken</div>
        </div>
        <div className="kpi-tile">
          <div className="kpi-value">{pointCount.toLocaleString()}</div>
          <div className="kpi-label">Datenpunkte empfangen</div>
        </div>
      </div>

      <div className="dashboard-grid">
        {/* Übersicht eingetroffener Daten */}
        <Card title="Daten-Übersicht" subtitle={`${metricKeys.length} Metriken empfangen`} className="card--wide">
          {metricKeys.length === 0 ? (
            <EmptyState title="Warte auf Daten…" message="Verbindung wird aufgebaut" />
          ) : (
            <div className="metric-grid">
              {metricKeys.map((key) => (
                <MetricCard key={key} metricKey={key} info={metrics[key]} />
              ))}
            </div>
          )}
        </Card>

        {/* Aktive Maschinen */}
        <Card title="Aktive Maschinen" subtitle={`${machineList.length} bekannt`}>
          {machineList.length === 0 ? (
            <EmptyState title="Keine Maschinen" message="Warte auf Statusmeldung…" />
          ) : (
            <ul className="machine-list">
              {machineList.map((m) => (
                <li key={m.machine_id} className="machine-item">
                  <StatusDot connected={isActive(m.status)} />
                  <span className="machine-id">{m.machine_id}</span>
                  <Badge label={m.status} color={isActive(m.status) ? 'green' : 'gray'} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Datenquelle */}
        <Card title="Datenquelle">
          {sourceList.length === 0 ? (
            <EmptyState title="Keine Quelle" message="Keine aktive Verbindung" />
          ) : (
            <ul className="source-list">
              {sourceList.map((s) => (
                <li key={s.id || s.type} className="source-item">
                  <span className="status-dot status-dot--on" />
                  <div>
                    <div className="source-name">{s.type}</div>
                    <div className="source-url">{s.url}</div>
                  </div>
                  <Badge label={s.type} color="blue" />
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
