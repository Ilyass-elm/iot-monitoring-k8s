// src/views/LiveFeedView.jsx
import { useState, useEffect } from 'react';
import { liveFeedStore } from '../services/liveFeedStore';
import { Card, Badge } from '../components/ui/index.jsx';

export function LiveFeedView() {
  const [rows, setRows] = useState(liveFeedStore.getRows());
  const [paused, setPaused] = useState(false);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    // Beim (Wieder-)Anzeigen sofort den aktuellen Stand übernehmen — der
    // Store sammelt im Hintergrund weiter, auch während dieser Tab nicht
    // sichtbar war.
    setRows(liveFeedStore.getRows());
    if (paused) return; // während Pause keine weiteren Updates anzeigen
    return liveFeedStore.subscribe(setRows);
  }, [paused]);

  const handleClear = () => {
    liveFeedStore.clear();
    setRows([]);
  };

  const filtered = filter
    ? rows.filter(
        (r) =>
          r.machine.toLowerCase().includes(filter.toLowerCase()) ||
          String(r.label).toLowerCase().includes(filter.toLowerCase())
      )
    : rows;

  return (
    <div className="view live-feed-view">
      <Card
        title="Live Datenstrom"
        subtitle={`${rows.length} Zeilen gepuffert (max ${liveFeedStore.MAX_ROWS})`}
        actions={
          <div className="live-controls">
            <input
              className="filter-input"
              placeholder="Maschine / Metrik filtern…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
            <button className={`btn btn-sm ${paused ? 'btn-warn' : 'btn-ghost'}`} onClick={() => setPaused((p) => !p)}>
              {paused ? 'Fortsetzen' : 'Pausieren'}
            </button>
            <button className="btn btn-sm btn-ghost" onClick={handleClear}>
              Leeren
            </button>
          </div>
        }
      >
        <div className="feed-table-wrap">
          <table className="feed-table">
            <thead>
              <tr>
                <th>Zeit</th>
                <th>Typ</th>
                <th>Maschine</th>
                <th>Metrik / Status</th>
                <th>Wert</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.id} className="feed-row">
                  <td className="feed-ts">{new Date(row.timestamp).toLocaleTimeString()}</td>
                  <td>
                    <Badge label={row.type} color={row.type === 'status' ? 'purple' : 'blue'} />
                  </td>
                  <td className="feed-machine">{row.machine}</td>
                  <td className="feed-key">{row.label}</td>
                  <td className="feed-value">
                    {typeof row.value === 'number' ? row.value.toFixed(3) : String(row.value)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="feed-empty">Keine Daten {filter ? 'für diesen Filter' : '– warte auf Stream…'}</div>
          )}
        </div>
      </Card>
    </div>
  );
}
