// src/App.jsx
import { useState, useEffect } from 'react';
import { wsService } from './services/websocketService';
// Side-effect-Imports: registrieren ihre WebSocket-Listener sofort beim
// App-Start, unabhängig davon, welcher Tab gerade sichtbar ist.
import './services/liveFeedStore';
import './services/statsStore';
import { Header } from './components/Header.jsx';
import { DashboardView } from './views/DashboardView.jsx';
import { LiveFeedView } from './views/LiveFeedView.jsx';
import { AiView } from './views/AiView.jsx';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    wsService.connect();
  }, []);

  return (
    <div className="app">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="main-content">
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'live' && <LiveFeedView />}
        {activeTab === 'ai' && <AiView />}
      </main>
    </div>
  );
}
