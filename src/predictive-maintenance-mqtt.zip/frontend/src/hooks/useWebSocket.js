// src/hooks/useWebSocket.js
import { useState, useEffect, useRef, useCallback } from 'react';
import { wsService } from '../services/websocketService';
import { api } from '../services/apiService';

/** Subscribe to a WebSocket event type */
export function useWsEvent(type, handler) {
  useEffect(() => {
    const unsub = wsService.on(type, handler);
    return unsub;
  }, [type, handler]);
}

/** Track WebSocket connection status */
export function useWsConnected() {
  const [connected, setConnected] = useState(wsService.isConnected());
  useWsEvent('connection', useCallback(({ connected }) => setConnected(connected), []));
  return connected;
}

/** Accumulate live data points for a specific metric (ring buffer) */
export function useMetricSeries(metricKey, maxPoints = 150) {
  const [series, setSeries] = useState([]);
  const bufferRef = useRef([]);

  useEffect(() => {
    bufferRef.current = [];
    setSeries([]);
  }, [metricKey]);

  useWsEvent(
    'data:point',
    useCallback(
      (points) => {
        const arr = Array.isArray(points) ? points : [points];
        for (const p of arr) {
          if (p.metricKey === metricKey) {
            bufferRef.current.push({ ...p, ts: p.timestamp });
            if (bufferRef.current.length > maxPoints) bufferRef.current.shift();
          }
        }
        setSeries([...bufferRef.current]);
      },
      [metricKey, maxPoints]
    )
  );

  return series;
}

/** Track all known metric keys from incoming data (hydriert initial per REST,
 *  damit beim erneuten Anzeigen des Tabs nichts auf "leer" zurückspringt) */
export function useAllMetrics() {
  const [metrics, setMetrics] = useState({});

  useEffect(() => {
    api.getLatest()
      .then((latest) => {
        // Erwartetes Format: { [metricKey]: { source, tags, lastValue } }
        if (latest && typeof latest === 'object') setMetrics(latest);
      })
      .catch(() => {});
  }, []);

  useWsEvent(
    'data:point',
    useCallback((points) => {
      const arr = Array.isArray(points) ? points : [points];
      setMetrics((prev) => {
        const next = { ...prev };
        for (const p of arr) {
          next[p.metricKey] = {
            source: p.source,
            tags: p.tags,
            lastValue: p.value,
          };
        }
        return next;
      });
    }, [])
  );

  return metrics;
}

/** Track known machines and their latest status (aus initialer Liste + Live-Updates) */
export function useMachines() {
  const [machines, setMachines] = useState({});

  useEffect(() => {
    api.getMachines()
      .then((list) => {
        const map = {};
        for (const m of list) map[m.machine_id] = m;
        setMachines(map);
      })
      .catch(() => {});
  }, []);

  useWsEvent(
    'machine:status',
    useCallback(({ machineId, status, timestamp }) => {
      setMachines((prev) => ({
        ...prev,
        [machineId]: { machine_id: machineId, status, updatedAt: timestamp },
      }));
    }, [])
  );

  return machines;
}
