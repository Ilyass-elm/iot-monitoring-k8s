// src/components/MetricCard.jsx
import { useMetricSeries } from '../hooks/useWebSocket';

export function MetricCard({ metricKey, info }) {
  const series = useMetricSeries(metricKey, 60);
  const last = series[series.length - 1];
  const value = last?.value ?? info?.lastValue ?? null;
  const machine = last?.tags?.machine || info?.tags?.machine || '';
  const metricName = last?.tags?.metric || info?.tags?.metric || metricKey.split('.').slice(-1)[0];

  // Mini-Sparkline der tatsächlich eingetroffenen letzten Werte
  const mini = series.slice(-30).map((p) => p.value);
  const minV = Math.min(...mini);
  const maxV = Math.max(...mini);
  const range = maxV - minV || 1;
  const W = 80, H = 30;
  const pts = mini
    .map((v, i) => {
      const x = (i / (mini.length - 1)) * W;
      const y = H - ((v - minV) / range) * H;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div className="metric-card" title={metricKey}>
      <div className="metric-card-top">
        <span className="metric-card-key">{metricName}</span>
        <span className="metric-card-machine">{machine}</span>
      </div>
      <div className="metric-card-value">
        {value !== null ? value.toFixed(2) : '—'}
      </div>
      {mini.length > 2 && (
        <svg width={W} height={H} className="sparkline">
          <polyline points={pts} fill="none" stroke="var(--accent)" strokeWidth="1.5" opacity="0.8" />
        </svg>
      )}
    </div>
  );
}
