// src/components/Header.jsx
import { useWsConnected } from '../hooks/useWebSocket';
import { StatusDot } from './ui/index.jsx';
import logo from '../assets/logo.svg';

const TABS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'live',      label: 'Live Feed' },
  { id: 'ai',        label: 'KI-Analyse' },
];

export function Header({ activeTab, onTabChange }) {
  const connected = useWsConnected();

  return (
    <header className="header">
      <div className="header-brand">
        {/* Platzhalter-Logo — einfach src/assets/logo.svg durch euer eigenes
            Logo ersetzen (gleicher Dateiname), keine weitere Anpassung nötig. */}
        <img className="brand-logo" src={logo} alt="Logo" width={32} height={32} />
        <div>
          <div className="brand-title">Convoyer App</div>
          <div className="brand-sub">Predictive Maintenance</div>
        </div>
      </div>

      <nav className="header-nav">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            className={`nav-tab ${activeTab === tab.id ? 'nav-tab--active' : ''}`}
            onClick={() => onTabChange(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      <div className="header-status">
        <StatusDot connected={connected} label={connected ? 'Verbunden' : 'Getrennt'} />
      </div>
    </header>
  );
}
