// src/components/ui/Badge.jsx
export function Badge({ label, color = 'blue' }) {
  const colors = {
    blue:   'var(--badge-blue)',
    green:  'var(--badge-green)',
    yellow: 'var(--badge-yellow)',
    red:    'var(--badge-red)',
    gray:   'var(--badge-gray)',
    purple: 'var(--badge-purple)',
  };
  return (
    <span className="badge" style={{ '--badge-color': colors[color] || colors.blue }}>
      {label}
    </span>
  );
}

// src/components/ui/Card.jsx
export function Card({ title, subtitle, children, className = '', actions }) {
  return (
    <div className={`card ${className}`}>
      {(title || actions) && (
        <div className="card-header">
          <div>
            {title && <h3 className="card-title">{title}</h3>}
            {subtitle && <p className="card-subtitle">{subtitle}</p>}
          </div>
          {actions && <div className="card-actions">{actions}</div>}
        </div>
      )}
      <div className="card-body">{children}</div>
    </div>
  );
}

// src/components/ui/StatusDot.jsx
export function StatusDot({ connected, label }) {
  return (
    <span className="status-dot-wrap">
      <span className={`status-dot ${connected ? 'status-dot--on' : 'status-dot--off'}`} />
      {label && <span className="status-dot-label">{label}</span>}
    </span>
  );
}

// src/components/ui/Spinner.jsx
export function Spinner({ size = 20 }) {
  return (
    <svg
      className="spinner"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
    >
      <circle cx="12" cy="12" r="10" opacity="0.25" />
      <path d="M12 2 a10 10 0 0 1 10 10" strokeLinecap="round" />
    </svg>
  );
}

// src/components/ui/EmptyState.jsx
export function EmptyState({ title, message }) {
  return (
    <div className="empty-state">
      <div className="empty-state-title">{title}</div>
      {message && <div className="empty-state-msg">{message}</div>}
    </div>
  );
}
