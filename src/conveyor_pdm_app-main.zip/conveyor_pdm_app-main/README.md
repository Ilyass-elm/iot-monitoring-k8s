## Clone this Repo

You can clone this repository using the following command:
```
git clone https://code.siemens.com/ilyass.el-moutaouakkil/conveyor_pdm_app.git
```

# Conveyor_PdM_App

The main purpose behind this application is to build the basis for a predictive maintenance approach. The Application is supposed to analyse incoming data from EMSs and predict possible failures, evaluates the healthe states of the carriers, and help the Maintenance team to live monitor the production chains.

The Convoyer App application will be running on an edge device (In the Production). It connects the EMSs via the OPC UA Protocol with a local-running dashboard. The Communication schema looks like this:

EMS (via OPC UA) -> Nodered Client (wandelt msgs in MQTT-Nachrichten um) -> EMS Daten + aktuellen Status (active/ not active) der verbundenen Maschinen werden über WebSocket zu Dashbord ermittelt -> Daten im Dashbaord zeigen.

The Application store data in InfluxDB. To forward the data from MQTT to InfluxDB a telegraf service is used.


## Setup
* You'll need Docker to run this application. The official Installation instructions (For Ubuntu) can be found [here](https://docs.docker.com/desktop/setup/install/linux/ubuntu/).

The services communicate with each other via a Docker Bridge Network.
* After Docker Installation, create a docker network using the following command:
```
docker create network proxy-redirect
```
If you'd like to name your network something else, make sure to adjust the compose file accordingly. Replace "proxy-redirect" wherever you find it in _compose.yaml_.
