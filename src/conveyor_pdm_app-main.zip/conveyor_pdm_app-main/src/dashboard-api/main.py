"""
Dashboard API service.

Responsibilities:
- Subscribe to MQTT telemetry + machine status topics
- Maintain live in-memory machine status (connected/disconnected)
- Stream live telemetry to dashboard clients over WebSocket, filtered
  per-client by whichever machine they currently have selected
- Serve historical telemetry from InfluxDB on demand

Env vars:
  MQTT_HOST, MQTT_PORT
  INFLUXDB_URL, INFLUXDB_TOKEN, INFLUXDB_ORG, INFLUXDB_BUCKET
"""

import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager

import aiomqtt
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from influxdb_client import InfluxDBClient

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("dashboard-api")

# --- Config -----------------------------------------------------------

MQTT_HOST = os.environ["MQTT_HOST"]
MQTT_PORT = int(os.environ.get("MQTT_PORT", 1883))

INFLUXDB_URL = os.environ["INFLUXDB_URL"]
INFLUXDB_TOKEN = os.environ["INFLUXDB_TOKEN"]
INFLUXDB_ORG = os.environ["INFLUXDB_ORG"]
INFLUXDB_BUCKET = os.environ.get("INFLUXDB_BUCKET", "telemetry")

TELEMETRY_TOPIC_FILTER = "ems/+/+"   # machine/<machine_id>/<metric>

# a machine is considered "online" if it has sent a message within this many
# seconds; otherwise the presence watcher marks it "offline"
OFFLINE_TIMEOUT_SECONDS = int(os.environ.get("OFFLINE_TIMEOUT_SECONDS", 30))
PRESENCE_CHECK_INTERVAL_SECONDS = 5

# --- Shared state -------------------------------------------------------

machine_status: dict[str, str] = {}                 # machine_id -> "online" / "offline"
machine_last_seen: dict[str, float] = {}            # machine_id -> monotonic timestamp of last message
client_selection: dict[WebSocket, str | None] = {}  # ws -> currently selected machine_id

influx_client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
query_api = influx_client.query_api()


# --- MQTT background task ------------------------------------------------

async def mqtt_listener():
    """Runs for the lifetime of the app, reconnecting on failure."""
    while True:
        try:
            async with aiomqtt.Client(MQTT_HOST, port=MQTT_PORT) as client:
                log.info("Connected to MQTT broker at %s:%s", MQTT_HOST, MQTT_PORT)
                await client.subscribe(TELEMETRY_TOPIC_FILTER)

                async for message in client.messages:
                    await handle_message(message)

        except aiomqtt.MqttError as exc:
            log.warning("MQTT connection lost (%s), retrying in 3s", exc)
            await asyncio.sleep(3)

async def handle_message(message: aiomqtt.Message):
    topic_parts = message.topic.value.split("/")

    # machine/<machine_id>/<metric>
    if len(topic_parts) != 3 or topic_parts[0] != "ems":
        log.debug("Unhandled topic: %s", message.topic.value)
        return

    _, machine_id, metric = topic_parts
    value = message.payload.decode(errors="replace")
    log.info("Received messages from topic: %s", message.topic)
    log.info("Metric is: %s | Value: %s", topic_parts[2], value)

    await mark_machine_active(machine_id)
    await broadcast_telemetry(machine_id, metric, value)

async def mark_machine_active(machine_id: str):
    """Records that a machine just sent a message, and flips it to 'online'
    if it wasn't already — this is the only signal we have of presence."""
    machine_last_seen[machine_id] = time.monotonic()

    if machine_status.get(machine_id) != "online":
        machine_status[machine_id] = "online"
        log.info("Current active EMS: %s", machine_status[machine_id])
        await broadcast_status(machine_id, "online")

async def presence_watcher():
    """Runs for the lifetime of the app. Periodically checks which machines
    haven't sent anything recently and marks them offline."""
    while True:
        await asyncio.sleep(PRESENCE_CHECK_INTERVAL_SECONDS)
        now = time.monotonic()

        for machine_id, last_seen in list(machine_last_seen.items()):
            if now - last_seen > OFFLINE_TIMEOUT_SECONDS and machine_status.get(machine_id) != "offline":
                machine_status[machine_id] = "offline"
                log.info("%s is inactive / offline.", machine_id)
                await broadcast_status(machine_id, "offline")


async def broadcast_telemetry(machine_id: str, axis: str, value: str):
    frame = json.dumps({
        "type": "telemetry",
        "machine_id": machine_id,
        "axis": axis,
        "value": value,
    })
    await _send_to_selected(machine_id, frame)


async def broadcast_status(machine_id: str, status: str):
    frame = json.dumps({
        "type": "status",
        "machine_id": machine_id,
        "status": status,
    })
    # status updates go to everyone, regardless of selection (drives the machine picker)
    for ws in list(client_selection.keys()):
        await _safe_send(ws, frame)


async def _send_to_selected(machine_id: str, frame: str):
    for ws, selected in list(client_selection.items()):
        if selected == machine_id:
            await _safe_send(ws, frame)


async def _safe_send(ws: WebSocket, frame: str):
    try:
        await ws.send_text(frame)
    except Exception:
        client_selection.pop(ws, None)


# --- App lifecycle --------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    mqtt_task = asyncio.create_task(mqtt_listener())
    presence_task = asyncio.create_task(presence_watcher())
    yield
    mqtt_task.cancel()
    presence_task.cancel()


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this for production
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- REST endpoints ---------------------------------------------------

@app.get("/machines")
async def list_machines():
    """Returns known machines and their last known connection status."""
    return machine_status


@app.get("/history/{machine_id}/{axis}")
async def get_history(machine_id: str, axis: str, minutes: int = 60):
    """Returns recent historical telemetry for a machine/axis from InfluxDB."""
    flux = f'''
    from(bucket: "{INFLUXDB_BUCKET}")
      |> range(start: -{minutes}m)
      |> filter(fn: (r) => r.machine_id == "{machine_id}" and r.axis == "{axis}")
    '''
    tables = query_api.query(flux)

    points = []
    for table in tables:
        for record in table.records:
            points.append({
                "time": record.get_time().isoformat(),
                "field": record.get_field(),
                "value": record.get_value(),
            })
    return {"machine_id": machine_id, "axis": axis, "points": points}


# --- WebSocket endpoint ------------------------------------------------

@app.websocket("/ws/live")
async def live_endpoint(websocket: WebSocket):
    await websocket.accept()
    client_selection[websocket] = None

    # send current machine list immediately so the dashboard can render the picker
    await websocket.send_text(json.dumps({"type": "ems", "ems": machine_status}))

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if msg.get("action") == "select_machine":
                client_selection[websocket] = msg.get("machine_id")
                log.info("Client selected machine: %s", msg.get("machine_id"))

    except WebSocketDisconnect:
        client_selection.pop(websocket, None)
