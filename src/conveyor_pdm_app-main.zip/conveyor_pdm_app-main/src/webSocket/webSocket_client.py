import asyncio
import json
import websockets

import logging

HOST = "dashboard-api"
PORT = 8000
MACHINE_ID = "EMS[1]"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("webSocket-client")

async def main():
    url = f"ws://{HOST}:{PORT}/ws/live"

    async with websockets.connect(url) as ws:
        log.info(f"Connected to {url}")

        # Receive initial machines list
        msg = await ws.recv()
        log.info("Initial message:")
        log.info(json.dumps(json.loads(msg), indent=2))

        # Select machine
        await ws.send(json.dumps({
            "action": "select_machine",
            "machine_id": MACHINE_ID
        }))

        log.info(f"Selected machine: {MACHINE_ID}")
        log.info("Waiting for messages...\n")

        while True:
            message = await ws.recv()

            try:
                data = json.loads(message)
                log.info(json.dumps(data, indent=2))
            except Exception:
                log.info(message)

asyncio.run(main())