// src/server.js
require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const path = require('path');

const logger = require('./utils/logger');
const connectorManager = require('./connectors/connectorManager');
const websocketService = require('./services/websocketService');
const WsSourceConnector = require('./connectors/wsSourceConnector');

// ── Routes ──────────────────────────────────────────────────────────────────
const dataRoutes = require('./routes/dataRoutes');
const systemRoutes = require('./routes/systemRoutes');

// ── App setup ────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// Serve built frontend (production)
const frontendDist = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendDist));

app.use('/api/data', dataRoutes);
app.use('/api/system', systemRoutes);

// Health check
app.get('/health', (_, res) => res.json({ status: 'ok', timestamp: Date.now() }));

// SPA fallback
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(frontendDist, 'index.html'), (err) => {
    if (err) res.status(200).send('Predictive Maintenance API running. Start the frontend separately.');
  });
});

// ── HTTP + WS server ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
const server = http.createServer(app);

websocketService.init(server);

server.listen(PORT, async () => {
  logger.info(`🚀 Server running on http://localhost:${PORT}`);

  // ── Einziger Datenanschluss: WebSocket-Client zur externen Quelle ─────────
  // Konfigurierbar über WS_SOURCE_URL, sonst zusammengesetzt aus HOST/PORT/PATH
  // (Standardwerte entsprechen der Vorlage webSocket/webSocket_client.py)
  const wsUrl =
    process.env.WS_SOURCE_URL ||
    `ws://${process.env.WS_SOURCE_HOST || 'dashboard-api'}:${process.env.WS_SOURCE_PORT || 8000}${process.env.WS_SOURCE_PATH || '/ws/live'}`;

  const source = new WsSourceConnector({ url: wsUrl });
  connectorManager.register(source);

  await connectorManager.startAll();
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down...');
  await connectorManager.stopAll();
  server.close(() => process.exit(0));
});
